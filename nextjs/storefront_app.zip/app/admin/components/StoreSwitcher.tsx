"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase-client";
import { ChevronDown } from "lucide-react";

interface Profile {
  id: string;
  slug: string;
  display_name: string | null;
}

export default function StoreSwitcher() {
  const router = useRouter();
  const pathname = usePathname();
  const search = useSearchParams();

  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [open, setOpen] = useState(false);

  const currentStore = search.get("store");
  const popRef = useRef<HTMLDivElement>(null);

  // fetch stores
  useEffect(() => {
    const supabase = createClient();
    let cancelled = false;

    (async () => {
      setLoading(true);
      setErrorMsg(null);
      const { data, error } = await supabase
        .from("profiles")
        .select("id, slug, display_name")
        .order("created_at", { ascending: true });
      if (cancelled) return;
      if (error) {
        setErrorMsg("Failed to load stores");
        setProfiles([]);
      } else {
        setProfiles((data ?? []) as Profile[]);
      }
      setLoading(false);
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  // active profile
  const active = useMemo(() => {
    if (!currentStore) return null;
    return profiles.find((p) => p.id === currentStore || p.slug === currentStore) || null;
  }, [profiles, currentStore]);

  function applyStore(idOrSlug: string) {
    const params = new URLSearchParams(search.toString());
    params.set("store", idOrSlug);
    router.push(`${pathname}?${params.toString()}`);
    setOpen(false);
  }

  // close on click outside / escape
  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (!open) return;
      if (popRef.current && !popRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", onDocClick);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDocClick);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const label = loading
    ? "Loading stores…"
    : active
    ? active.display_name || active.slug
    : profiles.length
    ? "Select a store"
    : errorMsg || "No stores found";

  return (
    <div className="relative" ref={popRef}>
      <button
        type="button"
        disabled={loading || (!!errorMsg && profiles.length === 0)}
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        className="inline-flex items-center gap-2 rounded-xl border border-black/10 bg-white px-3 py-2 text-sm font-medium hover:bg-neutral-50 disabled:opacity-60"
        title={label}
      >
        {label}
        <ChevronDown className={`h-4 w-4 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {/* Dropdown */}
      {open && (
        <div
          role="menu"
          aria-label="Select store"
          className="absolute z-50 mt-2 w-64 max-h-72 overflow-auto rounded-xl border border-black/10 bg-white p-1 shadow-md"
        >
          {profiles.map((p) => {
            const isActive = active?.id === p.id;
            return (
              <button
                key={p.id}
                role="menuitem"
                onClick={() => applyStore(p.id)}
                className={`block w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-neutral-50 ${
                  isActive ? "bg-neutral-100" : ""
                }`}
              >
                <div className="font-medium">{p.display_name || p.slug}</div>
                <div className="text-xs text-neutral-500">/{p.slug}</div>
              </button>
            );
          })}
          {!loading && profiles.length === 0 && (
            <div className="px-3 py-2 text-sm text-neutral-500">
              {errorMsg || "No stores yet. Create one to get started."}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
